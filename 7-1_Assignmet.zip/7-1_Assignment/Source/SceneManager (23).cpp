///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream> // Included for error reporting


namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const char* g_UVScaleName = "uvScale";
}

/***********************************************************
 * SceneManager()
 *
 * The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 * ~SceneManager()
 *
 * The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	DestroyGLTextures();
}

/***********************************************************
 * CreateGLTexture()
 *
 * This method is used for loading a texture from a file
 * and creating an OpenGL texture object.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 * BindGLTextures()
 *
 * This method binds the loaded textures to texture units.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 * DestroyGLTextures()
 *
 * This method is used for freeing the memory in all the
 * used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 * FindTextureID()
 *
 * This method is used for getting an ID for the previously
 * loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 * FindTextureSlot()
 *
 * This method is used for getting a slot index for the previously
 * loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (!m_objectMaterials.empty()) // Check if there are any materials defined
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		// Find the defined material that matches the tag
		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			// Pass the material properties into the shader
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
		else
		{
			// Optional: Handle case where material is not found, e.g., set a default material
			std::cerr << "Warning: Material with tag '" << materialTag << "' not found." << std::endl;
		}
	}
	else
	{
		std::cerr << "Warning: No object materials are defined." << std::endl;
	}
}
/***********************************************************
 * SetTextureUVScale()
 *
 * Set the texture UV scale into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setVec2Value(g_UVScaleName, glm::vec2(u, v));
	}
}

void SceneManager::SetupSceneLights()
{
	// Enable lighting in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Define the properties of a blue light source
	// Positioned behind and slightly above the top of the object
	glm::vec3 lightPosition = glm::vec3(5.0f, 4.0f, 5.0f); // Adjusted Y and Z-coordinates

	// Significantly increase light intensity for all components, focusing on blue
	glm::vec3 ambientColor = glm::vec3(0.7f, 0.6f, 0.6f); // Increased blue ambient 
	glm::vec3 diffuseColor = glm::vec3(0.8f, 0.8f, 0.7f); // Stronger blue diffuse 
	glm::vec3 specularColor = glm::vec3(0.8f, 0.8f, 0.6f); // Max blue specular

	// Set the light's properties in the shader
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", ambientColor);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", diffuseColor);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", specularColor);
	m_pShaderManager->setVec3Value("lightSources[0].position", lightPosition);

	


	

}
/***********************************************************
 * SetTransformations()
 *
 * This method is used for setting the transform buffer
 * using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	// matrix math for calculating the final model matrix
	modelView = translation * rotationY * rotationX * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		// pass the model matrix into the shader
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 * SetShaderColor()
 *
 * This method is used for setting the passed in color
 * into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		// pass the color values into the shader
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 * SetShaderTexture()
 *
 * This method is used for setting the passed in texture
 * into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		int textureSlot = FindTextureSlot(textureTag);
		if (textureSlot != -1)
		{
			// pass the texture slot into the shader
			m_pShaderManager->setIntValue(g_UseTextureName, true);
			m_pShaderManager->setIntValue(g_TextureValueName, textureSlot);
		}
		else
		{
			// Default to color if texture not found
			m_pShaderManager->setIntValue(g_UseTextureName, false);
		}
	}
}
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.empty()) // Use .empty() for checking size 0
	{
		return(false);
	}

	for (const auto& mat : m_objectMaterials) // Use range-based for loop for cleaner iteration
	{
		if (mat.tag.compare(tag) == 0)
		{
			material.ambientColor = mat.ambientColor;
			material.ambientStrength = mat.ambientStrength;
			material.diffuseColor = mat.diffuseColor;
			material.specularColor = mat.specularColor;
			material.shininess = mat.shininess;
			return(true); // Material found
		}
	}

	return(false); // Material not found
}

/***********************************************************
 * LoadSceneTextures()
 *
 * This method loads the textures for the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Load the specific textures for the bottle
	CreateGLTexture("textures/gold-seamless-texture.jpg", "gold_seamless");
	CreateGLTexture("textures/abstract.jpg", "abstract");
	CreateGLTexture("textures/plastic.jpg", "plastic");
	CreateGLTexture("textures/cap.jpg", "cap");
	CreateGLTexture("textures/rust2.jpg", "rust2");
	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 * PrepareScene()
 *
 * This method is used for preparing the 3D scene by loading
 * the shapes, textures in memory to support the 3D scene
 * rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// Load the meshes for the shapes we will use to build the bottle and the scene planes
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh(); // Ensure plane mesh is loaded for floor and wall
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();

	
	SetupSceneLights();
	// Load textures
	LoadSceneTextures();
}

/***********************************************************
 * RenderScene()
 *
 * This method is used for rendering the 3D scene by
 * transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Define a consistent offset to move the entire scene up
	const float sceneYOffset = 15.0f;

	// --- Render the Floor Plane (Base for the scene) ---
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f); // Large flat plane
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f + sceneYOffset, 0.0f); // At the origin, moved up
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("abstract");
	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f); // A darker blue for the floor
	

	m_basicMeshes->DrawPlaneMesh();

	// --- Render the Background Wall Plane ---
	// This plane is rotated to stand upright and positioned behind the scene.
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f); // Scale as a wall
	XrotationDegrees = 90.0f; // Rotate 90 degrees around X to make it vertical
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// Position it behind the objects and lifted to form a wall, moved up
	positionXYZ = glm::vec3(0.0f, 9.0f + sceneYOffset, -15.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	// Changed to a much lighter blue
	SetShaderTexture("abstract");
	SetShaderColor(0.8f, 0.8f, 0.8f, 1.0f); // Lighter blue color for the background wall

	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
	/* Draw the Main Body of the Bottle (as an elongated rectangular prism) */
	/****************************************************************/
	// set the XYZ scale for the mesh to create a taller, rectangular shape
	scaleXYZ = glm::vec3(3.0f, 6.0f, 2.0f);
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// set the XYZ position for the mesh, lifted by half its height to sit on the plane, and moved up
	positionXYZ = glm::vec3(0.0f, 3.0f + sceneYOffset, 0.0f);
	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	// Set the texture for the bottle body
	SetShaderTexture("plastic");
	SetShaderColor(0.2f, 0.2f, 0.4f, 0.6f);
	 // Corrected material tag to match definition
	glm::vec2 uvScale = glm::vec2(3.0f, 3.0f);
	
	// draw the cube mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/


	/****************************************************************/
	/* Draw the Tapered Top of the Bottle (Pyramid)                 */
	/****************************************************************/
	// set the XYZ scale for the mesh to match the body and taper upwards
	scaleXYZ = glm::vec3(3.0f, 1.5f, 2.0f);
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// set the XYZ position for the mesh, placing it on top of the body, and moved up
	positionXYZ = glm::vec3(0.0f, 6.0f + (1.5f / 2.0f) + sceneYOffset, 0.0f); // Box height 6.0, plus half pyramid height
	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	// Set the texture for the pyramid
	SetShaderTexture("plastic");
	

	SetShaderColor(0.2f, 0.2f, 0.4f, 0.5f);
	// draw the mesh with transformation values
	m_basicMeshes->DrawPyramid4Mesh(); // Changed to Pyramid4Mesh for consistency
	/****************************************************************/


	/****************************************************************/
	/* Draw the Cap                                                 */
	/****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(.7f, 0.5f, .7f);
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// set the XYZ position for the mesh, on top of the pyramid, and moved up
	positionXYZ = glm::vec3(0.0f, 5.25f + 1.5f + (0.5f / 2.0f) + sceneYOffset, 0.0f); // Box height 6.0, pyramid height 1.5, plus half cap height
	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	// Set the texture for the cap
	SetShaderTexture("cap");
	

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/***********************************/
	/* Draw the Main Body of the Bottle (as an elongated cylinder)  */
	/****************************************************************/
	// Set the XYZ scale for the mesh to create a taller, cylindrical shape
	scaleXYZ = glm::vec3(2.0f, 6.0f, 2.0f);
	// Set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// Set the XYZ position for the mesh, lifted by half its height to sit on the plane, and moved up
	positionXYZ = glm::vec3(0.0f, 3.0f + sceneYOffset, 0.0f);
	// Set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	// Set the texture for the bottle body and a transparent blue color
	const float newBottleXOffset = 5.0f;

	/****************************************************************/
	/* Draw the Main Body of the Second Bottle (as a cylinder) */
	/****************************************************************/
	// Re-using the same scale and height logic as the first bottle
	scaleXYZ = glm::vec3(1.2f, 6.0f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(newBottleXOffset, 0.0f + sceneYOffset, 0.0f); // Shifted to the right
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("plastic");
	SetShaderColor(0.2f, 0.2f, 0.4f, 0.5f); // Using the same color/transparency
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/


	/****************************************************************/
	/* Draw the Tapered Top/Shoulder of the Second Bottle (Tapered Cylinder) */
	/****************************************************************/
	scaleXYZ = glm::vec3(1.16f, .9f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(newBottleXOffset, 6.0f + (.1f / 1.9f) + sceneYOffset, 0.0f); // Shifted to the right
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("plastic");
	SetShaderColor(0.2f, 0.2f, 0.4f, 0.5f);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/


	/****************************************************************/
	/* Draw the Cap of the Second Bottle */
	/****************************************************************/
	scaleXYZ = glm::vec3(.47f, 0.25f, .9f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(newBottleXOffset, 7.5f + (-0.9f / 2.0f) + sceneYOffset, 0.0f); // Shifted to the right
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("plastic");
	SetShaderColor(0.2f, 0.2f, 0.4f, 0.7f);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();
	/***********************************/
	const float dumbbellZOffset = 5.8f; // Position it behind the bottles
	const float dumbbellXPosition = -4.5f; // Center it between the two bottles

	/****************************************************************/
/* Draw the Dumbbell Handle (Cylinder) */
/****************************************************************/
	scaleXYZ = glm::vec3(0.3f, 0.5f, 2.3f); // Thin cylinder for the handle, elongated in Z
	XrotationDegrees = 0.0f; // No X rotation
	YrotationDegrees = 90.0f; // Rotate to lie horizontally along the X-axis
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(dumbbellXPosition, 0.85f + sceneYOffset +1.07, dumbbellZOffset); // Slightly above the floor
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("rust2");
	SetShaderColor(0.4f, 0.4f, 0.4f, 1.0f); // Dark gray/black for metal
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
	/****************************************************************/

	/****************************************************************/
/* Draw the Left Dumbbell Weight (Sphere) */
/****************************************************************/
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f); // Sphere for the weight
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// Position the left weight relative to the handle along the X-axis
	positionXYZ = glm::vec3(dumbbellXPosition - 2.9f, 1.44f + sceneYOffset+ 1.0, dumbbellZOffset -.9);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("rust2");
	SetShaderColor(0.4f, 0.4f, 0.4f, 1.0f); // Dark gray/black for metal
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/****************************************************************/
	/* Draw the Right Dumbbell Weight (Sphere) */
	/****************************************************************/
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f); // Sphere for the weight
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// Position the right weight relative to the handle along the X-axis
	positionXYZ = glm::vec3(dumbbellXPosition + 2.0f, 1.4f + sceneYOffset +1.0, dumbbellZOffset);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("rust2");
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Dark gray/black for metal
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/
	/****************************************************************/
}