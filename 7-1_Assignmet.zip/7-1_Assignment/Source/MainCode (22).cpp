#include <iostream>          // error handling and output
#include <cstdlib>           // EXIT_FAILURE

#include <GL/glew.h>         // GLEW library
#include "GLFW/glfw3.h"      // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"
#include "Camera.h" // Include your Camera class

// Namespace for declaring global variables
namespace
{
    // Macro for window title
    const char* const WINDOW_TITLE = "7-1 Project Alexander Ray";

    // Main GLFW window
    GLFWwindow* g_Window = nullptr;

    // scene manager object for managing the 3D scene prepare and render
    SceneManager* g_SceneManager = nullptr;
    // shader manager object for dynamic interaction with the shader code
    ShaderManager* g_ShaderManager = nullptr;
    // view manager object for managing the 3D view setup and projection to 2D
    ViewManager* g_ViewManager = nullptr;

    // Camera object
    // Initial camera position set to view the bottle scene.
    // Adjust Y and Z to get a good initial view.
    Camera g_Camera(glm::vec3(0.0f, 20.0f, 22.0f));
    float g_lastX = 800.0f / 2.0f; // Initial mouse X position (center of screen)
    float g_lastY = 600.0f / 2.0f; // Initial mouse Y position (center of screen)
    bool g_firstMouse = true;

    // Timing
    float g_deltaTime = 0.0f; // Time between current frame and last frame
    float g_lastFrame = 0.0f; // Time of last frame

    // Projection mode toggle
    bool g_IsOrthographic = false; // Start in perspective view
}

// Function declarations - all functions that are called manually
// need to be pre-declared at the beginning of the source code.
bool InitializeGLFW();
bool InitializeGLEW();

// Input processing function
void processInput(GLFWwindow* window);
// Callback for keyboard input
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
// Callback for mouse cursor movement
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
// Callback for mouse scroll wheel
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);


/***********************************************************
 * main(int, char*)
 *
 * This function gets called after the application has been
 * launched.
 ***********************************************************/
int main(int argc, char* argv[])
{
    // if GLFW fails initialization, then terminate the application
    if (InitializeGLFW() == false)
    {
        return(EXIT_FAILURE);
    }

    // try to create a new shader manager object
    g_ShaderManager = new ShaderManager();
    // try to create a new view manager object
    g_ViewManager = new ViewManager(
        g_ShaderManager);

    // try to create the main display window
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

    // Set up input callbacks
    glfwSetKeyCallback(g_Window, key_callback);
    glfwSetCursorPosCallback(g_Window, mouse_callback);
    glfwSetScrollCallback(g_Window, scroll_callback);

    // Hide and capture mouse cursor
    glfwSetInputMode(g_Window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    // if GLEW fails initialization, then terminate the application
    if (InitializeGLEW() == false)
    {
        return(EXIT_FAILURE);
    }

    // load the shader code from the external GLSL files
    
    g_ShaderManager->LoadShaders(
        "../../Utilities/shaders/vertexShader.glsl",
        "../../Utilities/shaders/fragmentShader.glsl");
    g_ShaderManager->use();
    
    // try to create a new scene manager object and prepare the 3D scene
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();
    
    struct OBJECT_MATERIAL
    {
        float ambientStrength;
        glm::vec3 ambientColor;
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };
    // loop will keep running until the application is closed
    // or until an error has occurred
    while (!glfwWindowShouldClose(g_Window))
    {
        // Calculate delta time for frame-rate independent movement
        float currentFrame = glfwGetTime();
        g_deltaTime = currentFrame - g_lastFrame;
        g_lastFrame = currentFrame;

        // Process input (keyboard and mouse)
        processInput(g_Window);

        // Enable z-depth
        glEnable(GL_DEPTH_TEST);

        // Clear the frame and z buffers
        // Set clear color to a blue similar to the image background
        glClearColor(0.3f, 0.3f, 0.9f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Get the view matrix from the camera
        glm::mat4 view = g_Camera.GetViewMatrix();
        // Pass the view matrix to the shader
        g_ShaderManager->setMat4Value("view", view);

        // Get window dimensions for projection matrix
        int display_w, display_h;
        glfwGetFramebufferSize(g_Window, &display_w, &display_h);
        float aspectRatio = (float)display_w / (float)display_h;

        glm::mat4 projection;
        if (g_IsOrthographic)
        {
            
            float orthoSize = 10.0f; 
            projection = glm::ortho(-orthoSize * aspectRatio, orthoSize * aspectRatio,
                -orthoSize, orthoSize, 0.1f, 100.0f);

        }
        else
        {
            // Perspective projection
            projection = glm::perspective(glm::radians(g_Camera.Zoom), aspectRatio, 0.1f, 100.0f);
        }
        // Pass the projection matrix to the shader
        g_ShaderManager->setMat4Value("projection", projection);



        // refresh the 3D scene
        g_SceneManager->RenderScene();

        g_ShaderManager->setVec3Value("viewPos", g_Camera.Position);
        // Flips the the back buffer with the front buffer every frame.
        glfwSwapBuffers(g_Window);

        // query the latest GLFW events
        glfwPollEvents();
    }

    // clear the allocated manager objects from memory
    if (NULL != g_SceneManager)
    {
        delete g_SceneManager;
        g_SceneManager = NULL;
    }
    if (NULL != g_ViewManager)
    {
        delete g_ViewManager;
        g_ViewManager = NULL;
    }
    if (NULL != g_ShaderManager)
    {
        delete g_ShaderManager;
        g_ShaderManager = NULL;
    }

    // Terminates the program successfully
    exit(EXIT_SUCCESS);
}

/***********************************************************
 * processInput()
 *
 * This function processes keyboard input for camera movement.
 ***********************************************************/
void processInput(GLFWwindow* window)
{
    // Close window on ESC press
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // WASD for forward/backward/left/right panning
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(FORWARD, g_deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(BACKWARD, g_deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(LEFT, g_deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(RIGHT, g_deltaTime);

    // QE for up/down panning
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(UP, g_deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        g_Camera.ProcessKeyboard(DOWN, g_deltaTime);
}

/***********************************************************
 * key_callback()
 *
 * This function is a GLFW callback for keyboard input.
 * It's primarily used for single key press events,
 * continuous movement is handled in processInput.
 ***********************************************************/
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // Toggle perspective/orthographic view on P/O key press
    if (action == GLFW_PRESS) // Only trigger on key press, not hold or release
    {
        if (key == GLFW_KEY_P)
        {
            g_IsOrthographic = false; // Switch to Perspective
            std::cout << "Switched to Perspective View" << std::endl;
        }
        else if (key == GLFW_KEY_O)
        {
            g_IsOrthographic = true; // Switch to Orthographic
            std::cout << "Switched to Orthographic View" << std::endl;
            
        }
    }
}

/***********************************************************
 * mouse_callback()
 *
 * This function is a GLFW callback for mouse cursor movement.
 * It updates the camera's yaw and pitch.
 ***********************************************************/
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (g_firstMouse)
    {
        g_lastX = xpos;
        g_lastY = ypos;
        g_firstMouse = false;
    }

    float xoffset = xpos - g_lastX;
    float yoffset = g_lastY - ypos; // Reversed since Y-coordinates go from bottom to top

    g_lastX = xpos;
    g_lastY = ypos;

    g_Camera.ProcessMouseMovement(xoffset, yoffset);
}

/***********************************************************
 * scroll_callback()
 *
 * This function is a GLFW callback for mouse scroll wheel input.
 * It adjusts the camera's movement speed.
 ***********************************************************/
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    g_Camera.ProcessMouseScroll(static_cast<float>(yoffset));
}


/***********************************************************
 * InitializeGLFW()
 *
 * This function is used to initialize the GLFW library.
 ***********************************************************/
bool InitializeGLFW()
{
    // GLFW: initialize and configure library
    // --------------------------------------
    glfwInit();

#ifdef __APPLE__
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
    // GLFW: end -------------------------------

    return(true);
}

/***********************************************************
 * InitializeGLEW()
 *
 * This function is used to initialize the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
    // GLEW: initialize
    // -----------------------------------------
    GLenum GLEWInitResult = GLEW_OK;

    // try to initialize the GLEW library
    GLEWInitResult = glewInit();
    if (GLEW_OK != GLEWInitResult)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }
    // GLEW: end -------------------------------

    // Displays a successful OpenGL initialization message
    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

    return(true);
}
